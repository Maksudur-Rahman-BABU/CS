﻿namespace Project_03
{
    public class Book
    {
        public object Title { get; internal set; }
        public object Type { get; internal set; }
        public object Price { get; internal set; }
    }
}