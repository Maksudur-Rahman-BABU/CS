﻿using System;

namespace Project_03
{
    internal class ITBook
    {
        public int ID { get; internal set; }
        public string Title { get; internal set; }
        public decimal Price { get; internal set; }
        public string[] Authors { get; internal set; }
        public string Publisher { get; internal set; }
        public DateTime PublishDate { get; internal set; }
        public string[] Tags { get; internal set; }
        public object Type { get; internal set; }
    }
}